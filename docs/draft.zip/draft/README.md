# Tabular Transformation Discovery Harness — Research Paper Draft

Bản draft bài báo nghiên cứu khoa học được cấu trúc và định dạng hoàn chỉnh, tuân thủ theo quy chuẩn hướng dẫn từ tài liệu **"How to write a scientific paper: Data Science and AI"** (Rohitash Chandra) và tích hợp đầy đủ các số liệu thực nghiệm từ hệ thống benchmark.

---

## 1. Thông tin tác giả & Bài báo

- **Tác giả:** Đào Thế Việt
- **Email:** daothevietnb123@gmail.com
- **Tiêu đề:** *Benchmarking Inverse Reasoning and Tabular Transformation Discovery in Frontier Large Language Models: A Two-Tier Autonomous Evaluation Harness*

---

## 2. Cấu trúc thư mục `draft/` để tải lên Overleaf

Thư mục `draft/` chứa toàn bộ tài nguyên cần thiết để tải lên Overleaf:

```text
draft/
├── main.tex          # File LaTeX chính (chứa toàn bộ nội dung, bảng số liệu, hình TikZ/PGFPlots)
├── references.bib    # File BibTeX chứa toàn bộ trích dẫn học thuật chuẩn
└── README.md         # Tài liệu hướng dẫn sử dụng và thông số kỹ thuật
```

---

## 3. Hướng dẫn Render trên Overleaf

1. Nén thư mục `draft/` (hoặc chọn các file `main.tex`, `references.bib`) thành file `.zip`.
2. Truy cập [Overleaf](https://www.overleaf.com), bấm **New Project** $\to$ **Upload Project**, và tải file `.zip` lên.
3. Trong phần **Menu** (góc trên bên trái Overleaf):
   - **Compiler:** `pdfLaTeX` (hoặc `XeLaTeX` / `LuaLaTeX`).
   - **Main document:** `main.tex`.
4. Bấm **Recompile** để xuất bản PDF chất lượng cao.

---

## 4. Tóm tắt các Phần trong Bài báo

1. **Abstract:** Trình bày vấn đề (Problem statement), mục tiêu (Aims), đóng góp kỹ thuật (Contributions), tóm tắt kết quả định lượng (Results), và tuyên bố tái lập thí nghiệm (Reproducibility).
2. **Section 1 (Introduction):** Dẫn dắt từ tổng quan mô hình LLM trên dữ liệu bảng $\to$ Thách thức của bài toán suy luận ngược $\to$ Động lực $\to$ 5 đóng góp chính $\to$ Lộ trình bài báo.
3. **Section 2 (Background and Related Work):** Khảo cứu các công trình nền tảng về Agentic Code Reasoning, Mô hình hóa dữ liệu bảng và Dữ liệu tổng hợp (Synthetic Data), cùng Bài toán suy luận ngược (Inverse Problems & Reverse Engineering).
4. **Section 3 (Methodology):** 
   - Định nghĩa toán học bài toán và 6 cấp độ phức tạp ngữ pháp AST (Level 0 $\to$ Level 5).
   - Kiến trúc 2 tầng (Two-Tier Evaluation Harness): Tầng khám phá (Discovery Tier) độc lập với Tầng đánh giá kiểm thử ẩn (Evaluation Tier).
   - Cơ chế cách ly và an toàn sandbox (Sanitized environment).
   - Bộ quản trị ngân sách thích ứng (Adaptive Tiered Budget Controller).
   - Hệ thống chỉ số đánh giá 2 chiều: Đánh giá chức năng hộp đen (*Transformed Column Accuracy*) và Đánh giá biểu thức tượng trưng hộp trắng (*Operator F1-score*, *Exact Sequence Accuracy*, AST validation).
5. **Section 4 (Experimental Evaluation and Results):**
   - Bảng kết quả tổng hợp 144 tasks benchmark cho Agentic LLM (GPT-5-mini) và Brute-force baseline.
   - Phân tích so sánh giữa Benchmark Accuracy (phạt 0.0 khi fail/timeout) và Conditional Accuracy (khi nộp thành công).
   - Phân loại độ khó theo từng nhóm toán tử (Invertible vs Periodic/Trigonometric vs Piecewise/Interactions).
   - Động lực tiêu thụ tài nguyên (Tokens, Tool calls, CPU time, Wall time).
6. **Section 5 (Discussion):** Đối chiếu mục tiêu, ý nghĩa an toàn dữ liệu/chống rò rỉ dữ liệu tổng hợp (Synthetic data privacy leakage), hạn chế của nghiên cứu, và hướng phát triển tương lai (Neuro-symbolic search, RL for exploration).
7. **Section 6 (Conclusions):** Tổng kết đóng góp và tuyên bố tác động khoa học.
